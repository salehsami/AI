
# coding: utf-8

# In[1]:


print("Hello World")


# In[6]:


bob = {"name":"Saleh","age":"18","class":"matric"}
print("bobs name is ", bob["name"],"and his class is",bob["class"])


# In[7]:


# Activity 1
myList1 = []
print("Entering first list...")
for i in range(5):
    n = int(input("Enter value: "))
    myList1.append(n)
myList2 = []
print("Entering second list....")
for i in range(5):
    v = int(input("Enter value: "))
    myList2.append(v)
list3 = myList1 + myList2
print(list3)


# In[8]:


# Activity 2
myList1 = []
print("Enter objects in the list")
for i in range(5):
    n = int(input("Enter value: "))
    myList1.append(n)
v = int(input("Enter what you want to find: "))
if v in myList1:
    print("Found")
else :
    print("Not found")


# In[27]:


# Activity 3
d = {}
d["spam"] = 3
print(d)
print(d["spam"])
d.update({"spam" : 1, "eggs": 2})
print(d)
print("dictionary has ",len(d), " items" )
print("keys:", list(d.keys()))
print("Values:", list(d.values()))
for key in d:
    print(key,d[key])
print(d.get("toast", "not in dictionary"))
del(d["eggs"])
print(d)


# In[34]:


# Activity 4
def main():
    print("Enter the person's age group ", end="")
    ageGroup = input("(child, minor, adult, or senior): ")
    print("The admission fee is", determineAdmissionFee(ageGroup), "dollars." )
def determineAdmissionFee(ageGroup):
        if ageGroup == "child": # age < 6
            return 0 # free
        elif ageGroup == "minor": # age 6 to 17
            return 5 # $5
        elif ageGroup == "adult": # age 18 to 64
            return 10
        elif ageGroup == "senior": # age >= 65
            return 8
main()


# In[37]:


# Graded activity 1
def main():
    ageGroup = input("Enter your age group child,adult,senior: ")
    print("The admissuion fee is: ",(determineAdmissionFee(ageGroup)))
def determineAdmissionFee(ageGroup):
    dict = {"child":0, "minor":5, "adult":10, "senior":8}
    return dict[ageGroup]
main()


# In[ ]:


# Graded activity 2
sentence = input("Enter the sentence: ")
array = list(sentence)
list1 = []

for i in range(len(array)):
    count = 0
    s = array[i]
    for i in range(len(array)):
        if (s == array[i]):
            count = count + 1
    
    if (s not in list1):
        list1.append(s)
        list1.append(count)

for i in range(0,len(list1)-1,2):
    print(list1[i], " ", list1[i+1])
    i = i + 2


# In[ ]:


# Graded activity 2
import math
X =-3.14
while( X <= 3.14) :
   print("{:.2f}".format(round(math.cos(X), 2)), end = " " )
   compute = math.sin(X+0.01)
   computef = compute / 0.01
   print("{:.2f}".format(round(computef, 2)))
   X += 0.1

