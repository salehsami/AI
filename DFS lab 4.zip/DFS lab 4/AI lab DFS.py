"""Saleh Ahmad Sami
FA19-BSC-071
BCS-5B"""
# coding: utf-8

# In[16]:


class Node:

    def __init__(
        self,
        state,
        parent,
        actions,
        totalCost,
        ):
        self.state = state
        self.parent = parent
        self.actions = actions
        self.totalCost = totalCost


# In[17]:


def actionSequence(graph, initialState, goalState):
    solution = [goalState]
    currentParent = graph[goalState].parent
    while currentParent != None:
        solution.append(currentParent)
        currentParent = graph[currentParent].parent
    solution.reverse()
    return solution


# In[18]:


def DFS(initialState, goalState, graph):
    frontier = [initialState]
    explored = []
    while len(frontier) != 0:
        currentNode = frontier.pop(len(frontier)-1)
        print(currentNode)
        explored.append(currentNode)
        for child in graph[currentNode].actions:
            if child not in frontier and child not in explored:
                graph[child].parent = currentNode
                if graph[child].state == goalState:
                    return actionSequence(graph, initialState,
                            goalState)
                frontier.append(child)


# In[19]:


graph = {
    'Oradea': Node('Oradea', None, ['Zerind', 'Sibiu'], None),
    'Zerind': Node('Zerind', None, ['Arad'], None),
    'Arad': Node('Arad', None, ['Timisoara', 'Sibiu'], None),
    'Timisoara': Node('Timisoara', None, ['Lugoj'], None),
    'Lugoj': Node('Lugoj', None, ['Mehadia'], None),
    'Mehadia': Node('Mehadia', None, ['Drobeta'], None),
    'Drobeta': Node('Drobeta', None, ['Craiova'], None),
    'Craiova': Node('Craiova', None, ['Rimnicu Vitcea', 'Pitesti'],
                    None),
    'Rimnicu Vitcea': Node('Rimnicu Vitcea', None, ['Sibiu'], None),
    'Pitesti': Node('Pitesti', None, ['Bucharest'], None),
    'Sibiu': Node('Sibiu', None, ['Fagaras'], None),
    'Fagaras': Node('Fagaras', None, ['Bucharest'], None),
    'Bucharest': Node('Bucharest', None, ['Giurgui', 'Urziceni'],
                      None),
    'Giurgui': Node('Giurgui', None, ['Bucharest'], None),
    'Urziceni': Node('Urziceni', None, ['Hirsowa', 'Vaslui'], None),
    'Hirsowa': Node('Hirsowa', None, ['Eforic'], None),
    'Eforic': Node('Eforic', None, ['Hirsowa'], None),
    'Vaslui': Node('Vaslui', None, ['Iasi'], None),
    'Iasi': Node('Iasi', None, ['Neamt'], None),
    'Neamt': Node('Neamt', None, ['Iasi'], None),
    }

print (DFS('Oradea', 'Giurgui', graph))

